
package cce107;
import java.sql.*;
import java.util.*;
public class sql {
    



public class SQL {
    
    private InfoFillOut obj = new InfoFillOut();
    
    String name = InfoFillOut.jTextFieldfirstname;

  
    static void InsertData() {
        String url = "jdbc:mysql://185.207.164.129:3306/s6260_CCEProject";
        String user = "u6260_kcKIUM8xxu";
        String password = "snaA+zK4E313a8i^E5.@cm4.";
        
        String name = obj.firstName;
        Date checkin =
        Date checkout =
        String room =
        int fee =
        

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            
            //Change ang (Name, Age, Salary) kay mao ni column name
            String sql = "INSERT INTO Table1 (Name, Check-in, Check-out, Room, Fee) VALUES (?, ?, ?, ?, ?)";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            
            
            statement.setString(1, "");
            statement.setDate(2, );
            statement.setDate(3, );
            statement.setString(4, "321");
            statement.setInt(5, );

            // Execute the statement
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new row was inserted successfully!");
            }
        } catch (SQLException e) {
            System.err.println("Error occurred while connecting to the database: " + e.getMessage());
        }
    }
    
        static void ReadData() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Failed to load JDBC driver: " + e.getMessage());
            return;
        }

        String url = "jdbc:mysql://185.207.164.129:3306/s6260_CCEProject";
        String user = "u6260_kcKIUM8xxu";
        String password = "snaA+zK4E313a8i^E5.@cm4.";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "SELECT * FROM Table1";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                // Retrieve data from the result set
                //Diri magkuha ug data, change lang ang column name heh
                int name = resultSet.getString("name");
                Date checkin = resultSet.getDate("check-in");
                Date checkout = resultSet.getDate("check-out");
                String room resultSet.getInt("room");
                int fee = resultSet.getDouble("fee");

                // Process the retrieved data
                System.out.println("Name " + name +"Check-in Date: " + checkin + ", Check-out Date: " + checkout + ", Room: " + room + "Total Fee: " + fee);
            }
        } catch (SQLException e) {
            System.err.println("Error occurred while reading data from the database: " + e.getMessage());
        }
    }

    
}

}
